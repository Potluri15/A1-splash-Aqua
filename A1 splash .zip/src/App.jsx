import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import './index.css';
import F12Main from './F12Main';

import AboutUs from './pages/AboutUs';
import AnimationTestFrame from './pages/AnimationTestFrame';
import ContactUs from './pages/ContactUs';
import Footer from './pages/Footer';
import Home from './pages/Home';
import ProductList1 from './pages/ProductList1';
import ProductList10 from './pages/ProductList10';
import ProductList11 from './pages/ProductList11';
import ProductList12 from './pages/ProductList12';
import ProductList13 from './pages/ProductList13';
import ProductList14 from './pages/ProductList14';
import ProductList15 from './pages/ProductList15';
import ProductList16 from './pages/ProductList16';
import ProductList17 from './pages/ProductList17';
import ProductList18 from './pages/ProductList18';
import ProductList2 from './pages/ProductList2';
import ProductList3 from './pages/ProductList3';
import ProductList4 from './pages/ProductList4';
import ProductList5 from './pages/ProductList5';
import ProductList6 from './pages/ProductList6';
import ProductList7 from './pages/ProductList7';
import ProductList8 from './pages/ProductList8';
import ProductList9 from './pages/ProductList9';
import Products from './pages/Products';
import Property1Default from './pages/Property1Default';
import Property1Default from './pages/Property1Default';
import Property1Default1 from './pages/Property1Default1';
import Property1Default1 from './pages/Property1Default1';
import Property1Default2 from './pages/Property1Default2';
import Property1Default2 from './pages/Property1Default2';
import Property1Default3 from './pages/Property1Default3';
import Property1Default3 from './pages/Property1Default3';
import Property1Default4 from './pages/Property1Default4';
import Property1Default5 from './pages/Property1Default5';
import Property1Disabled from './pages/Property1Disabled';
import Property1Disabled1 from './pages/Property1Disabled1';
import Property1Disabled2 from './pages/Property1Disabled2';
import Property1Disabled3 from './pages/Property1Disabled3';
import Property1Error from './pages/Property1Error';
import Property1Error1 from './pages/Property1Error1';
import Property1Error2 from './pages/Property1Error2';
import Property1Error3 from './pages/Property1Error3';
import Property1Focus from './pages/Property1Focus';
import Property1Focus1 from './pages/Property1Focus1';
import Property1Focus2 from './pages/Property1Focus2';
import Property1Focus3 from './pages/Property1Focus3';
import Property1Frame1 from './pages/Property1Frame1';
import Property1Frame2 from './pages/Property1Frame2';
import Property1Frame3 from './pages/Property1Frame3';
import Property1Hover from './pages/Property1Hover';
import Property1Hover1 from './pages/Property1Hover1';
import Property1Hover2 from './pages/Property1Hover2';
import Property1Hover3 from './pages/Property1Hover3';
import Property1Variant2 from './pages/Property1Variant2';
import Property1Variant21 from './pages/Property1Variant21';
import Property1Variant22 from './pages/Property1Variant22';
import Property1Variant23 from './pages/Property1Variant23';
import Property1Variant24 from './pages/Property1Variant24';
import Property1Variant25 from './pages/Property1Variant25';
import Property1Variant3 from './pages/Property1Variant3';
import Property1Variant31 from './pages/Property1Variant31';
import Property1Variant4 from './pages/Property1Variant4';
import ProuctInformation from './pages/ProuctInformation';
import ProuctInformation1 from './pages/ProuctInformation1';
import ProuctInformation1 from './pages/ProuctInformation1';
import ProuctInformation10 from './pages/ProuctInformation10';
import ProuctInformation10 from './pages/ProuctInformation10';
import ProuctInformation11 from './pages/ProuctInformation11';
import ProuctInformation11 from './pages/ProuctInformation11';
import ProuctInformation12 from './pages/ProuctInformation12';
import ProuctInformation12 from './pages/ProuctInformation12';
import ProuctInformation13 from './pages/ProuctInformation13';
import ProuctInformation14 from './pages/ProuctInformation14';
import ProuctInformation15 from './pages/ProuctInformation15';
import ProuctInformation16 from './pages/ProuctInformation16';
import ProuctInformation17 from './pages/ProuctInformation17';
import ProuctInformation18 from './pages/ProuctInformation18';
import ProuctInformation19 from './pages/ProuctInformation19';
import ProuctInformation2 from './pages/ProuctInformation2';
import ProuctInformation2 from './pages/ProuctInformation2';
import ProuctInformation20 from './pages/ProuctInformation20';
import ProuctInformation21 from './pages/ProuctInformation21';
import ProuctInformation22 from './pages/ProuctInformation22';
import ProuctInformation23 from './pages/ProuctInformation23';
import ProuctInformation24 from './pages/ProuctInformation24';
import ProuctInformation25 from './pages/ProuctInformation25';
import ProuctInformation26 from './pages/ProuctInformation26';
import ProuctInformation27 from './pages/ProuctInformation27';
import ProuctInformation28 from './pages/ProuctInformation28';
import ProuctInformation29 from './pages/ProuctInformation29';
import ProuctInformation3 from './pages/ProuctInformation3';
import ProuctInformation3 from './pages/ProuctInformation3';
import ProuctInformation30 from './pages/ProuctInformation30';
import ProuctInformation31 from './pages/ProuctInformation31';
import ProuctInformation32 from './pages/ProuctInformation32';
import ProuctInformation33 from './pages/ProuctInformation33';
import ProuctInformation34 from './pages/ProuctInformation34';
import ProuctInformation35 from './pages/ProuctInformation35';
import ProuctInformation36 from './pages/ProuctInformation36';
import ProuctInformation37 from './pages/ProuctInformation37';
import ProuctInformation38 from './pages/ProuctInformation38';
import ProuctInformation39 from './pages/ProuctInformation39';
import ProuctInformation4 from './pages/ProuctInformation4';
import ProuctInformation4 from './pages/ProuctInformation4';
import ProuctInformation40 from './pages/ProuctInformation40';
import ProuctInformation41 from './pages/ProuctInformation41';
import ProuctInformation42 from './pages/ProuctInformation42';
import ProuctInformation43 from './pages/ProuctInformation43';
import ProuctInformation44 from './pages/ProuctInformation44';
import ProuctInformation5 from './pages/ProuctInformation5';
import ProuctInformation5 from './pages/ProuctInformation5';
import ProuctInformation6 from './pages/ProuctInformation6';
import ProuctInformation6 from './pages/ProuctInformation6';
import ProuctInformation7 from './pages/ProuctInformation7';
import ProuctInformation7 from './pages/ProuctInformation7';
import ProuctInformation8 from './pages/ProuctInformation8';
import ProuctInformation8 from './pages/ProuctInformation8';
import ProuctInformation9 from './pages/ProuctInformation9';
import ProuctInformation9 from './pages/ProuctInformation9';
import ThankYouPage from './pages/ThankYouPage';


const router = createBrowserRouter([
  { path: '/', element: <F12Main /> },
{ path: '/AboutUs', element: <AboutUs /> },
{ path: '/AnimationTestFrame', element: <AnimationTestFrame /> },
{ path: '/ContactUs', element: <ContactUs /> },
{ path: '/Footer', element: <Footer /> },
{ path: '/Home', element: <Home /> },
{ path: '/ProductList1', element: <ProductList1 /> },
{ path: '/ProductList10', element: <ProductList10 /> },
{ path: '/ProductList11', element: <ProductList11 /> },
{ path: '/ProductList12', element: <ProductList12 /> },
{ path: '/ProductList13', element: <ProductList13 /> },
{ path: '/ProductList14', element: <ProductList14 /> },
{ path: '/ProductList15', element: <ProductList15 /> },
{ path: '/ProductList16', element: <ProductList16 /> },
{ path: '/ProductList17', element: <ProductList17 /> },
{ path: '/ProductList18', element: <ProductList18 /> },
{ path: '/ProductList2', element: <ProductList2 /> },
{ path: '/ProductList3', element: <ProductList3 /> },
{ path: '/ProductList4', element: <ProductList4 /> },
{ path: '/ProductList5', element: <ProductList5 /> },
{ path: '/ProductList6', element: <ProductList6 /> },
{ path: '/ProductList7', element: <ProductList7 /> },
{ path: '/ProductList8', element: <ProductList8 /> },
{ path: '/ProductList9', element: <ProductList9 /> },
{ path: '/Products', element: <Products /> },
{ path: '/Property1Default', element: <Property1Default /> },
{ path: '/Property1Default', element: <Property1Default /> },
{ path: '/Property1Default1', element: <Property1Default1 /> },
{ path: '/Property1Default1', element: <Property1Default1 /> },
{ path: '/Property1Default2', element: <Property1Default2 /> },
{ path: '/Property1Default2', element: <Property1Default2 /> },
{ path: '/Property1Default3', element: <Property1Default3 /> },
{ path: '/Property1Default3', element: <Property1Default3 /> },
{ path: '/Property1Default4', element: <Property1Default4 /> },
{ path: '/Property1Default5', element: <Property1Default5 /> },
{ path: '/Property1Disabled', element: <Property1Disabled /> },
{ path: '/Property1Disabled1', element: <Property1Disabled1 /> },
{ path: '/Property1Disabled2', element: <Property1Disabled2 /> },
{ path: '/Property1Disabled3', element: <Property1Disabled3 /> },
{ path: '/Property1Error', element: <Property1Error /> },
{ path: '/Property1Error1', element: <Property1Error1 /> },
{ path: '/Property1Error2', element: <Property1Error2 /> },
{ path: '/Property1Error3', element: <Property1Error3 /> },
{ path: '/Property1Focus', element: <Property1Focus /> },
{ path: '/Property1Focus1', element: <Property1Focus1 /> },
{ path: '/Property1Focus2', element: <Property1Focus2 /> },
{ path: '/Property1Focus3', element: <Property1Focus3 /> },
{ path: '/Property1Frame1', element: <Property1Frame1 /> },
{ path: '/Property1Frame2', element: <Property1Frame2 /> },
{ path: '/Property1Frame3', element: <Property1Frame3 /> },
{ path: '/Property1Hover', element: <Property1Hover /> },
{ path: '/Property1Hover1', element: <Property1Hover1 /> },
{ path: '/Property1Hover2', element: <Property1Hover2 /> },
{ path: '/Property1Hover3', element: <Property1Hover3 /> },
{ path: '/Property1Variant2', element: <Property1Variant2 /> },
{ path: '/Property1Variant21', element: <Property1Variant21 /> },
{ path: '/Property1Variant22', element: <Property1Variant22 /> },
{ path: '/Property1Variant23', element: <Property1Variant23 /> },
{ path: '/Property1Variant24', element: <Property1Variant24 /> },
{ path: '/Property1Variant25', element: <Property1Variant25 /> },
{ path: '/Property1Variant3', element: <Property1Variant3 /> },
{ path: '/Property1Variant31', element: <Property1Variant31 /> },
{ path: '/Property1Variant4', element: <Property1Variant4 /> },
{ path: '/ProuctInformation', element: <ProuctInformation /> },
{ path: '/ProuctInformation1', element: <ProuctInformation1 /> },
{ path: '/ProuctInformation1', element: <ProuctInformation1 /> },
{ path: '/ProuctInformation10', element: <ProuctInformation10 /> },
{ path: '/ProuctInformation10', element: <ProuctInformation10 /> },
{ path: '/ProuctInformation11', element: <ProuctInformation11 /> },
{ path: '/ProuctInformation11', element: <ProuctInformation11 /> },
{ path: '/ProuctInformation12', element: <ProuctInformation12 /> },
{ path: '/ProuctInformation12', element: <ProuctInformation12 /> },
{ path: '/ProuctInformation13', element: <ProuctInformation13 /> },
{ path: '/ProuctInformation14', element: <ProuctInformation14 /> },
{ path: '/ProuctInformation15', element: <ProuctInformation15 /> },
{ path: '/ProuctInformation16', element: <ProuctInformation16 /> },
{ path: '/ProuctInformation17', element: <ProuctInformation17 /> },
{ path: '/ProuctInformation18', element: <ProuctInformation18 /> },
{ path: '/ProuctInformation19', element: <ProuctInformation19 /> },
{ path: '/ProuctInformation2', element: <ProuctInformation2 /> },
{ path: '/ProuctInformation2', element: <ProuctInformation2 /> },
{ path: '/ProuctInformation20', element: <ProuctInformation20 /> },
{ path: '/ProuctInformation21', element: <ProuctInformation21 /> },
{ path: '/ProuctInformation22', element: <ProuctInformation22 /> },
{ path: '/ProuctInformation23', element: <ProuctInformation23 /> },
{ path: '/ProuctInformation24', element: <ProuctInformation24 /> },
{ path: '/ProuctInformation25', element: <ProuctInformation25 /> },
{ path: '/ProuctInformation26', element: <ProuctInformation26 /> },
{ path: '/ProuctInformation27', element: <ProuctInformation27 /> },
{ path: '/ProuctInformation28', element: <ProuctInformation28 /> },
{ path: '/ProuctInformation29', element: <ProuctInformation29 /> },
{ path: '/ProuctInformation3', element: <ProuctInformation3 /> },
{ path: '/ProuctInformation3', element: <ProuctInformation3 /> },
{ path: '/ProuctInformation30', element: <ProuctInformation30 /> },
{ path: '/ProuctInformation31', element: <ProuctInformation31 /> },
{ path: '/ProuctInformation32', element: <ProuctInformation32 /> },
{ path: '/ProuctInformation33', element: <ProuctInformation33 /> },
{ path: '/ProuctInformation34', element: <ProuctInformation34 /> },
{ path: '/ProuctInformation35', element: <ProuctInformation35 /> },
{ path: '/ProuctInformation36', element: <ProuctInformation36 /> },
{ path: '/ProuctInformation37', element: <ProuctInformation37 /> },
{ path: '/ProuctInformation38', element: <ProuctInformation38 /> },
{ path: '/ProuctInformation39', element: <ProuctInformation39 /> },
{ path: '/ProuctInformation4', element: <ProuctInformation4 /> },
{ path: '/ProuctInformation4', element: <ProuctInformation4 /> },
{ path: '/ProuctInformation40', element: <ProuctInformation40 /> },
{ path: '/ProuctInformation41', element: <ProuctInformation41 /> },
{ path: '/ProuctInformation42', element: <ProuctInformation42 /> },
{ path: '/ProuctInformation43', element: <ProuctInformation43 /> },
{ path: '/ProuctInformation44', element: <ProuctInformation44 /> },
{ path: '/ProuctInformation5', element: <ProuctInformation5 /> },
{ path: '/ProuctInformation5', element: <ProuctInformation5 /> },
{ path: '/ProuctInformation6', element: <ProuctInformation6 /> },
{ path: '/ProuctInformation6', element: <ProuctInformation6 /> },
{ path: '/ProuctInformation7', element: <ProuctInformation7 /> },
{ path: '/ProuctInformation7', element: <ProuctInformation7 /> },
{ path: '/ProuctInformation8', element: <ProuctInformation8 /> },
{ path: '/ProuctInformation8', element: <ProuctInformation8 /> },
{ path: '/ProuctInformation9', element: <ProuctInformation9 /> },
{ path: '/ProuctInformation9', element: <ProuctInformation9 /> },
{ path: '/ThankYouPage', element: <ThankYouPage /> },
]);

export default function App() {
  return (
    <RouterProvider router={router} />
  );
}