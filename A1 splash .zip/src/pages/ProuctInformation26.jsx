export default function ProuctInformation26() {
  return (
    <div className="bg-[#254A65] flex flex-col items-center p-[0_0_0.1px_0] w-[1920px] box-sizing-border">
      <img className="absolute top-[-387px] right-[-268px] w-[783px] h-[752px]" />
      <div className="relative m-[0_94.1px_284.7px_56px] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        Home
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        About us
        </div>
        <div className="m-[27.3px_0_28px_0] flex flex-row justify-between w-[355.9px] h-[fit-content] box-sizing-border">
          <div className="rounded-[80px] bg-[#F5C572] relative flex p-[9.7px_0_11.3px_0.2px] w-[151px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
            Products
            </span>
          </div>
          <div className="m-[9.7px_0_11.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          Contact Us
          </div>
        </div>
      </div>
      <div className="relative m-[0_108.3px_148px_108.3px] flex flex-row self-end w-[fit-content] box-sizing-border">
        <div className="bg-[url('assets/images/VerticalMountingRoPlant1.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[15px_172px_0_0] w-[628px] h-[452px]">
        </div>
        <div className="m-[0_0_35px_0] flex flex-col box-sizing-border">
          <div className="m-[0_0_88px_0] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
          Vertical mounting <br />
          plant
          </div>
          <span className="break-words font-['Montserrat'] font-medium text-[32px] text-[#FFFFFF]">
          Our Water Purification Systems provide the best <br />
          solutions for industrial purposes. They are designed to deliver clean and safe drinking <br />
          water.
          </span>
        </div>
      </div>
      <div className="rounded-[250px] bg-[#FFFFFF] relative m-[0_0_133px_357px] flex p-[24.2px_0_24.8px_0px] w-[271px] box-sizing-border">
        <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#254A65]">
        Enquire
        </span>
      </div>
      <div className="bg-[#FFFFFF] relative m-[0_0_74px_109px] w-[1229px] h-[4px]">
      </div>
      <div className="relative m-[0_846.9px_38px_0] inline-block break-words font-['Montserrat'] font-bold text-[36px] text-[#FFFFFF]">
      Details
      </div>
      <div className="relative m-[0_31.2px_89px_0] inline-block break-words font-['Montserrat'] font-medium text-[32px] text-[#FFFFFF]">
      The Vertical Mounting Plant is engineered for installations where space is limited and vertical space can be utilized. This configuration supports equipment such as pumps, tanks, and valves arranged vertically, which helps in optimizing floor space and improving accessibility. Commonly used in water treatment, chemical processing, and industrial applications, vertical mounting enhances operational efficiency and simplifies maintenance by leveraging vertical space effectively.
      </div>
      <div className="bg-[#FFFFFF] relative m-[0_0_576px_109px] w-[1229px] h-[4px]">
      </div>
      <div className="relative flex p-[274px_84px_73.8px_84px] w-[1920px] box-sizing-border">
        <img className="rounded-tl-[500px] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]" />
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[137px] top-[190.9px] w-[632px] h-[395px]">
        </div>
        <div className="relative flex flex-col items-center w-[1591px] h-[fit-content] box-sizing-border">
          <div className="m-[0_0_20px_432px] flex flex-row justify-between w-[703px] box-sizing-border">
            <div className="rounded-[100px] bg-[#254A65] relative m-[3px_0_0_0] flex p-[17px_0_19px_4.3px] w-[226px] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Explore
              </span>
            </div>
            <div className="rounded-[100px] bg-[#254A65] relative m-[0_0_3px_0] flex p-[20px_19.8px_16px_22px] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Get In touch
              </span>
            </div>
          </div>
          <div className="m-[0_0_29.7px_545.6px] flex flex-row justify-between w-[726.6px] box-sizing-border">
            <div className="m-[0_18px_0.3px_0] inline-block w-[117px] break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
            Home
            </div>
            <div className="flex flex-row box-sizing-border">
              <div className="m-[8px_26.6px_0_0] flex w-[45px] h-[40px] box-sizing-border">
                <img className="rounded-[2px] w-[31.9px] h-[28.3px]" />
              </div>
              <div className="m-[0_0_0.3px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
              +91 9030027002
              </div>
            </div>
          </div>
          <div className="m-[0_49px_23.1px_0] flex flex-row justify-between w-[1542px] box-sizing-border">
            <div className="relative m-[114.9px_33px_0_0] inline-block w-[417px] break-words font-['Source_Serif_Pro','Roboto_Condensed'] font-bold text-[56px] tracking-[0.4px] text-[#000000]">
            A1 Splash Aqua
            </div>
            <div className="m-[0_0_12.9px_0] flex flex-row box-sizing-border">
              <div className="m-[0_124.1px_0_0] flex flex-col box-sizing-border">
                <div className="m-[0_0_30px_0] inline-block self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                About Us
                </div>
                <div className="m-[0_0_30px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Products &amp; Services
                </div>
                <span className="self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Contact Us
                </span>
              </div>
              <div className="m-[20px_26.3px_34.7px_0] flex flex-col items-center w-[33.8px] h-[fit-content] box-sizing-border">
                <div className="m-[0_5.1px_60px_4.3px] flex w-[45px] h-[40px] box-sizing-border">
                  <img className="w-[24.4px] h-[30px]" />
                </div>
                <div className="flex w-[45px] h-[40px] box-sizing-border">
                  <img className="rounded-[2px] w-[33.8px] h-[23.3px]" />
                </div>
              </div>
              <div className="m-[3px_0_31px_0] flex flex-col items-center box-sizing-border">
                <div className="m-[0_13px_26px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Lakshmipuram 4 th lane Guntur - 522007
                </div>
                <span className="break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                mannepavan@gmail.com
                </span>
              </div>
            </div>
          </div>
          <img className="self-end w-[94px] h-[89.1px]" />
        </div>
      </div>
    </div>
  )
}