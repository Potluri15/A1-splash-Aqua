export default function Property1Variant25() {
  return (
    <div className="rounded-[250px] bg-[#254A65] flex p-[26px_0_28px_0] box-sizing-border">
      <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#FFFFFF]">
      Enquire
      </span>
    </div>
  )
}