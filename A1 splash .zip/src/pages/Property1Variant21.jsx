export default function Property1Variant21() {
  return (
    <div className="flex flex-row justify-between w-[1807.3px] box-sizing-border">
      <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
      </div>
      <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
      Home
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[27.7px_0_27.7px_0] flex p-[9.3px_1.8px_11.7px_0] w-[151px] h-[fit-content] box-sizing-border">
        <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#282F55]">
        About us
        </span>
      </div>
      <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
      Products
      </div>
      <div className="m-[37px_0px_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
      Contact Us
      </div>
    </div>
  )
}