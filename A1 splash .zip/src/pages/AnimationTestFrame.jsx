export default function AnimationTestFrame() {
  return (
    <div className="bg-[#282F55] flex flex-col items-end p-[82px_0_303px_0] w-[1088px] box-sizing-border">
      <div className="relative m-[0_0_54px_0] p-[90px_0_0_0] w-[943px] h-[180px] box-sizing-border">
        <div className="relative w-[437px] h-[77px]">
          <p className="absolute right-[-16.3px] bottom-[-205px] break-words font-['Montserrat'] font-bold text-[80px] tracking-[0.4px] text-[#27C2B0]">
          <span className="every-need-and-every-thing-sub-17"></span><span></span>
          </p>
        </div>
        <span className="absolute left-[50%] top-[0px] translate-x-[-50%] break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
        Clean Water Solutions for <br />
        
        </span>
      </div>
      <div className="rounded-[250px] bg-[#FFFFFF] relative m-[0_178px_0_0] flex self-center p-[27px_0_26px_0] w-[222px] box-sizing-border">
        <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#254A65]">
        Learn more
        </span>
      </div>
    </div>
  )
}