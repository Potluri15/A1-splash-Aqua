export default function Home() {
  return (
    <div className="bg-[#254A65] flex flex-col items-center p-[0_0_0.1px_0] w-[1920px] box-sizing-border">
      <img className="absolute top-[-43px] right-[-500px] w-[1269px] h-[1144px]" />
      <div className="relative m-[0_94.1px_177.7px_56px] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="rounded-[80px] bg-[#FFFFFF] relative m-[28px_0_27.3px_0] flex p-[9px_0_12px_2.2px] w-[151px] h-[fit-content] box-sizing-border">
          <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#355975]">
          Home
          </span>
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        About us
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Products
        </div>
        <div className="m-[37px_0px_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Contact Us
        </div>
      </div>
      <div className="relative m-[0_185px_66px_68px] flex flex-row w-[1667px] box-sizing-border">
        <div className="m-[99px_14px_0_0] flex flex-col w-[952px] h-[fit-content] box-sizing-border">
          <div className="relative m-[0_0_232px_0] p-[90px_0_0_0] w-[943px] h-[180px] box-sizing-border">
            <div className="relative w-[437px] h-[77px]">
              <p className="absolute right-[-16.3px] bottom-[-205px] break-words font-['Montserrat'] font-bold text-[80px] tracking-[0.4px] text-[#27C2B0]">
              <span className="every-need-and-every-thing-sub-17"></span><span></span>
              </p>
            </div>
            <span className="absolute left-[50%] top-[0px] translate-x-[-50%] break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
            Clean Water Solutions for <br />
            
            </span>
          </div>
          <div className="rounded-[250px] bg-[#FFFFFF] relative m-[0_5px_0_5px] flex self-start p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#254A65]">
            Learn more
            </span>
          </div>
        </div>
        <div className="rounded-[30px] bg-[url('assets/images/FireflyRealisticCleanWater829561.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_0_28px_0] w-[701px] h-[541px]">
        </div>
      </div>
      <div className="relative m-[0_73px_149px_73px] inline-block self-start break-words font-['Montserrat'] font-medium text-[32px] tracking-[0.4px] text-[#FFFFFF]">
      Experience the benefits of our advanced water purification systems, designed to provide clean and safe water for both residential and industrial use.
      </div>
      <div className="relative m-[0_152.8px_72px_119.6px] flex flex-row w-[fit-content] box-sizing-border">
        <div className="m-[72px_314.6px_92px_0] inline-block text-center break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
        Clean Water for Healthier Life<br />
        
        </div>
        <span className="break-words font-['Montserrat'] font-medium text-[36px] tracking-[0.4px] text-[#FFFFFF]">
        Our Water Purification system utilises advanced technology to remove impurities and contaminants ensuring you have access to clean and safe drinking water. With Smart and efficient operation our system provides a reliable solution for both residential and industrial purposes. 
        </span>
      </div>
      <div className="relative m-[0_79px_141px_127px] flex flex-row gap-[0_140px] w-[fit-content] box-sizing-border">
        <div className="rounded-[40px] bg-[#FEFEFE] relative flex flex-col items-center p-[59px_44.4px_102px_44.4px] w-[478px] box-sizing-border">
          <div className="bg-[url('assets/images/Filter.png')] bg-[50%_50%] bg-contain bg-no-repeat m-[0_8px_53px_0] w-[150px] h-[150px]">
          </div>
          <div className="m-[0_8.2px_76px_0] inline-block text-center break-words font-['IM_FELL_French_Canon'] font-normal text-[45px] tracking-[0.4px] text-[#1B355F]">
          Efficient Water Filteration
          </div>
          <span className="self-start text-center break-words font-['Montserrat'] font-medium text-[25px] tracking-[0.4px] text-[#1B355F]">
          Our System goes through multiple stages of filtration to remove harmful substances and purify water quality
          </span>
        </div>
        <div className="rounded-[40px] bg-[#FEFEFE] relative flex flex-col items-center p-[55px_34.5px_96px_35.4px] box-sizing-border">
          <div className="bg-[url('assets/images/Tools.png')] bg-[50%_50%] bg-contain bg-no-repeat m-[0_0_55px_1.1px] w-[150px] h-[150px]">
          </div>
          <div className="m-[0_0_54px_0] inline-block text-center break-words font-['IM_FELL_French_Canon'] font-normal text-[45px] tracking-[0.4px] text-[#1B355F]">
          Easy Installation and Maintenance
          </div>
          <span className="m-[0_4px_0_8.9px] text-center break-words font-['Montserrat'] font-medium text-[25px] tracking-[0.4px] text-[#1B355F]">
          Our water purification system features a streamlined design for effortless installation, ensuring you can have it up and running in no time.
          </span>
        </div>
        <div className="rounded-[40px] bg-[#FEFEFE] relative flex flex-col items-end p-[59px_36.8px_102px_39.3px] box-sizing-border">
          <div className="bg-[url('assets/images/Cash.png')] bg-[50%_50%] bg-contain bg-no-repeat m-[0_0_24px_51.5px] self-center w-[150px] h-[150px]">
          </div>
          <div className="m-[0_0_52px_0] inline-block text-center break-words font-['IM_FELL_French_Canon'] font-normal text-[45px] tracking-[0.4px] text-[#1B355F]">
          Cost-Effective Solution for Clean Water
          </div>
          <span className="m-[0_6.7px_0_0] text-center break-words font-['Montserrat'] font-medium text-[25px] tracking-[0.4px] text-[#1B355F]">
          Our water purification system offers a cost-effective solution, delivering high-quality clean water without breaking the bank.
          </span>
        </div>
      </div>
      <div className="relative m-[0_138px_212px_138px] flex flex-row self-start w-[fit-content] box-sizing-border">
        <div className="m-[106px_188.9px_106px_0] inline-block break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
        Providing Eco-Friendly Solutions for a Better Future<br />
        
        </div>
        <div className="rounded-[30px] bg-[url('assets/images/WhatsAppImage20240726At1303129Dec91321.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat w-[498px] h-[494px]">
        </div>
      </div>
      <div className="relative m-[0_6px_0.3px_0] flex flex-row justify-between w-[1476px] box-sizing-border">
        <div className="bg-[url('assets/images/Humaaans1Character1.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_0_61.5px_0] w-[500px] h-[346.3px]">
        </div>
        <div className="bg-[url('assets/images/TheLittleThingsBusinessPlanning1.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[14px_0_0_0] w-[500px] h-[393.8px]">
        </div>
      </div>
      <div className="relative m-[0_160.3px_14px_160.3px] flex flex-row justify-between self-end w-[1496.9px] box-sizing-border">
        <div className="m-[0_41px_12px_0] inline-block w-[472px] break-words font-['IM_FELL_French_Canon'] font-normal text-[70px] tracking-[0.4px] text-[#FFFFFF]">
        Eco Friendly
        </div>
        <div className="m-[12px_0_0_0] inline-block break-words font-['IM_FELL_French_Canon'] font-normal text-[70px] tracking-[0.4px] text-[#FFFFFF]">
        Easy Maintenance
        </div>
      </div>
      <div className="relative m-[0_169.2px_131px_169.2px] flex flex-row self-end w-[fit-content] box-sizing-border">
        <span className="m-[0_350.4px_0_0] break-words font-['Montserrat'] font-medium text-[36px] tracking-[0.4px] text-[#FFFFFF]">
        Our water purification systems utilize state-of-the-art filtration technology to provide you with clean and healthy water for your home or business. Say goodbye to contaminants and enjoy the purest water possible.
        </span>
        <div className="m-[0_0_44px_0] inline-block break-words font-['Montserrat'] font-medium text-[36px] tracking-[0.4px] text-[#FFFFFF]">
        Our systems are designed for ease of use and require minimal maintenance. Enjoy the benefits of clean water without the hassle of complicated upkeep or frequent filter changes.
        </div>
      </div>
      <div className="relative m-[0_0.2px_22px_0] inline-block text-center break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Get Consultation today 
      </div>
      <div className="relative m-[0_0_67px_0.9px] inline-block text-center break-words font-['Montserrat'] font-medium text-[36px] tracking-[0.4px] text-[#FFFFFF]">
      Get a consultation today and discover how our water purification solutions can benefit you!
      </div>
      <div className="rounded-[250px] bg-[#FFFFFF] relative m-[0_1px_143px_0] flex p-[26px_0_28px_0] w-[221px] box-sizing-border">
        <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#254A65]">
        Enquire
        </span>
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_118px_356px_117px] flex flex-col items-center p-[73px_83.9px_111px_83.9px] w-[1685px] box-sizing-border">
        <div className="m-[0_0_20px_49px] inline-block break-words font-['Montserrat'] font-bold text-[60px] tracking-[0.4px] text-[#000000]">
        Explore Our Products
        </div>
        <div className="m-[0_0_26px_47.6px] inline-block break-words font-['Montserrat'] font-bold text-[25px] tracking-[0.4px] text-[#000000]">
        Stay informed with our latest blog content
        </div>
        <div className="m-[0_18.1px_63px_22.1px] flex flex-row justify-between w-[1477px] box-sizing-border">
          <div className="rounded-[30px] bg-[url('assets/images/WhatsAppImage20240727At12363733B3De931.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat w-[394px] h-[241px]">
          </div>
          <div className="rounded-[30px] bg-[url('assets/images/WhatsAppImage20240726At131935A48B7B3B1.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat w-[304px] h-[241px]">
          </div>
          <div className="rounded-[30px] bg-[url('assets/images/WhatsAppImage20240727At123119Ade73F3A1.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat m-[5px_0_4px_0] w-[232px] h-[232px]">
          </div>
        </div>
        <div className="flex flex-row justify-between self-end w-[1432.3px] box-sizing-border">
          <span className="m-[0_24px_0_0] w-[336px] text-center break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          The importance of water purification
          </span>
          <span className="text-center break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          The importance of water purification
          </span>
          <span className="text-center break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          The importance of water purification
          </span>
        </div>
      </div>
      <div className="relative flex p-[274px_84px_73.8px_84px] w-[1920px] box-sizing-border">
        <img className="rounded-tl-[500px] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]" />
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[137px] top-[190.9px] w-[632px] h-[395px]">
        </div>
        <div className="relative flex flex-col items-center w-[1591px] h-[fit-content] box-sizing-border">
          <div className="m-[0_0_20px_432px] flex flex-row justify-between w-[703px] box-sizing-border">
            <div className="rounded-[100px] bg-[#355975] relative m-[3px_0_0_0] flex p-[17px_0_19px_4.3px] w-[226px] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Explore
              </span>
            </div>
            <div className="rounded-[100px] bg-[#355975] relative m-[0_0_3px_0] flex p-[20px_19.8px_16px_22px] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Get In touch
              </span>
            </div>
          </div>
          <div className="m-[0_0_29.7px_545.6px] flex flex-row justify-between w-[726.6px] box-sizing-border">
            <div className="m-[0_18px_0.3px_0] inline-block w-[117px] break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
            Home
            </div>
            <div className="m-[0_0px_0_0] flex flex-row box-sizing-border">
              <div className="m-[8px_26.6px_0_0] flex w-[45px] h-[40px] box-sizing-border">
                <img className="rounded-[2px] w-[31.9px] h-[28.3px]" />
              </div>
              <div className="m-[0_0_0.3px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
              +91 9030027002
              </div>
            </div>
          </div>
          <div className="m-[0_49px_23.1px_0] flex flex-row justify-between w-[1542px] box-sizing-border">
            <div className="relative m-[114.9px_33px_0_0] inline-block w-[417px] break-words font-['Source_Serif_Pro','Roboto_Condensed'] font-bold text-[56px] tracking-[0.4px] text-[#000000]">
            A1 Splash Aqua
            </div>
            <div className="m-[0_0_12.9px_0] flex flex-row box-sizing-border">
              <div className="m-[0_124.1px_0_0] flex flex-col box-sizing-border">
                <div className="m-[0_0_30px_0] inline-block self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                About Us
                </div>
                <div className="m-[0_0_30px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Products &amp; Services
                </div>
                <span className="self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Contact Us
                </span>
              </div>
              <div className="m-[20px_26.3px_34.7px_0] flex flex-col items-center w-[33.8px] h-[fit-content] box-sizing-border">
                <div className="m-[0_5.1px_60px_4.3px] flex w-[45px] h-[40px] box-sizing-border">
                  <img className="w-[24.4px] h-[30px]" />
                </div>
                <div className="flex w-[45px] h-[40px] box-sizing-border">
                  <img className="rounded-[2px] w-[33.8px] h-[23.3px]" />
                </div>
              </div>
              <div className="m-[3px_0_31px_0] flex flex-col items-center box-sizing-border">
                <div className="m-[0_13px_26px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Lakshmipuram 4 th lane Guntur - 522007
                </div>
                <span className="break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                mannepavan@gmail.com
                </span>
              </div>
            </div>
          </div>
          <img className="self-end w-[94px] h-[89.1px]" />
        </div>
      </div>
    </div>
  )
}