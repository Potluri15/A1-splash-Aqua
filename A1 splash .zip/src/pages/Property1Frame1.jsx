export default function Property1Frame1() {
  return (
    <div className="p-[90px_0_0_0] w-[943px] box-sizing-border">
      <div className="relative w-[437px] h-[77px]">
        <p className="absolute right-[-16.3px] bottom-[-205px] break-words font-['Montserrat'] font-bold text-[80px] tracking-[0.4px] text-[#27C2B0]">
        <span className="every-need-and-every-thing-sub-17"></span><span></span>
        </p>
      </div>
      <span className="absolute left-[50%] top-[0px] translate-x-[-50%] break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Clean Water Solutions for <br />
      
      </span>
    </div>
  )
}