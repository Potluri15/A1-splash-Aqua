export default function ProductList13() {
  return (
    <div className="bg-[#254A65] flex flex-col items-center p-[1px_0_0.1px_0] w-[1920px] box-sizing-border">
      <img className="absolute top-[-101px] right-[-119.4px] w-[634.4px] h-[553.7px]" />
      <div className="relative m-[0_94.1px_176.7px_56px] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        Home
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        About us
        </div>
        <div className="m-[27.3px_0_28px_0] flex flex-row justify-between w-[355.9px] h-[fit-content] box-sizing-border">
          <div className="rounded-[80px] bg-[#F5C572] relative flex p-[9.7px_0_11.3px_0.2px] w-[151px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
            Products
            </span>
          </div>
          <div className="m-[9.7px_0_11.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          Contact Us
          </div>
        </div>
      </div>
      <div className="relative m-[0_750px_46px_0] inline-block break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Reverse Osmosis Plant
      </div>
      <div className="relative m-[0_786.8px_160px_0] inline-block break-words font-['Montserrat'] font-medium text-[36px] tracking-[0.4px] text-[#FFFFFF]">
      Explore our range of water purification systems for industrial and residential purposes
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_150px_33px_151px] flex flex-row p-[110px_0_91.3px_94px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/HorizontalMountingPlant1.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_196px_0_0] w-[375px] h-[248.7px]">
        </div>
        <div className="m-[19px_0_14.7px_0] flex flex-col items-center box-sizing-border">
          <div className="m-[0_0_46px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          Horizontal Mounting<br />
          plant
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_64.6px_0_0] flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_150px_357px_151px] flex flex-row p-[117px_0_98.3px_106px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/VerticalMountingRoPlant1.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_170px_0_0] w-[375px] h-[234.8px]">
        </div>
        <div className="m-[19px_0_31.8px_0] flex flex-col items-center box-sizing-border">
          <div className="m-[0_0_15px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
           Vertical mounting <br />
          plant
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_6.7px_0_0] flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="bg-[url('assets/images/RoBasic2Hp2.png')] bg-[50%_50%] bg-cover bg-no-repeat relative m-[0_0_143px_218px] w-[0px] h-[0px]">
      </div>
      <div className="relative flex p-[274px_84px_73.8px_84px] w-[1920px] box-sizing-border">
        <img className="rounded-tl-[500px] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]" />
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[137px] top-[190.9px] w-[632px] h-[395px]">
        </div>
        <div className="relative flex flex-col items-center w-[1591px] h-[fit-content] box-sizing-border">
          <div className="m-[0_0_20px_432px] flex flex-row justify-between w-[703px] box-sizing-border">
            <div className="rounded-[100px] bg-[#254A65] relative m-[3px_0_0_0] flex p-[17px_0_19px_4.3px] w-[226px] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Explore
              </span>
            </div>
            <div className="rounded-[100px] bg-[#254A65] relative m-[0_0_3px_0] flex p-[20px_19.8px_16px_22px] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Get In touch
              </span>
            </div>
          </div>
          <div className="m-[0_0_29.7px_545.6px] flex flex-row justify-between w-[726.6px] box-sizing-border">
            <div className="m-[0_18px_0.3px_0] inline-block w-[117px] break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
            Home
            </div>
            <div className="flex flex-row box-sizing-border">
              <div className="m-[8px_26.6px_0_0] flex w-[45px] h-[40px] box-sizing-border">
                <img className="rounded-[2px] w-[31.9px] h-[28.3px]" />
              </div>
              <div className="m-[0_0_0.3px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
              +91 9030027002
              </div>
            </div>
          </div>
          <div className="m-[0_49px_23.1px_0] flex flex-row justify-between w-[1542px] box-sizing-border">
            <div className="relative m-[114.9px_33px_0_0] inline-block w-[417px] break-words font-['Source_Serif_Pro','Roboto_Condensed'] font-bold text-[56px] tracking-[0.4px] text-[#000000]">
            A1 Splash Aqua
            </div>
            <div className="m-[0_0_12.9px_0] flex flex-row box-sizing-border">
              <div className="m-[0_124.1px_0_0] flex flex-col box-sizing-border">
                <div className="m-[0_0_30px_0] inline-block self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                About Us
                </div>
                <div className="m-[0_0_30px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Products &amp; Services
                </div>
                <span className="self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Contact Us
                </span>
              </div>
              <div className="m-[20px_26.3px_34.7px_0] flex flex-col items-center w-[33.8px] h-[fit-content] box-sizing-border">
                <div className="m-[0_5.1px_60px_4.3px] flex w-[45px] h-[40px] box-sizing-border">
                  <img className="w-[24.4px] h-[30px]" />
                </div>
                <div className="flex w-[45px] h-[40px] box-sizing-border">
                  <img className="rounded-[2px] w-[33.8px] h-[23.3px]" />
                </div>
              </div>
              <div className="m-[3px_0_31px_0] flex flex-col items-center box-sizing-border">
                <div className="m-[0_13px_26px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Lakshmipuram 4 th lane Guntur - 522007
                </div>
                <span className="break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                mannepavan@gmail.com
                </span>
              </div>
            </div>
          </div>
          <img className="self-end w-[94px] h-[89.1px]" />
        </div>
      </div>
    </div>
  )
}