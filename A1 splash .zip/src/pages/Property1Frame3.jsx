export default function Property1Frame3() {
  return (
    <div className="p-[90px_0_0_0] w-[733px] box-sizing-border">
      <div className="relative w-[447px] h-[98px]">
        <p className="absolute top-[-184px] right-[-6.3px] break-words font-['Montserrat'] font-bold text-[80px] tracking-[0.4px] text-[#FFFFFF]">
        <span className="every-need-and-every-thing-sub-13"></span><span></span>
        </p>
      </div>
      <span className="absolute left-[50%] top-[0px] translate-x-[-50%] break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Clean Water Solutions for <br />
      
      </span>
    </div>
  )
}