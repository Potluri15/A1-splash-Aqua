export default function Property1Variant24() {
  return (
    <div className="rounded-[250px] bg-[#254A65] flex p-[27px_0_26px_0] box-sizing-border">
      <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#FFFFFF]">
      Learn more
      </span>
    </div>
  )
}