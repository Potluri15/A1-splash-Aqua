export default function Property1Variant3() {
  return (
    <div className="rounded-[250px] bg-[#F5C572] flex flex-row justify-between p-[4px_10px_4px_0] box-sizing-border">
      <div className="m-[16px_18.5px_11px_0] inline-block w-[55px] break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#282F55]">
      1.
      </div>
      <div className="flex flex-row box-sizing-border">
        <div className="m-[13px_63.4px_14px_0] inline-block break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#282F55]">
        2.
        </div>
        <div className="rounded-[250px] bg-[#282F55] relative flex p-[10px_0_17px_11px] w-[164px] box-sizing-border">
          <span className="break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#FFFFFF]">
          3.
          </span>
        </div>
      </div>
    </div>
  )
}