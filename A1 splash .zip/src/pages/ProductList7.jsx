export default function ProductList7() {
  return (
    <div className="bg-[#254A65] flex flex-col p-[0_0_0.1px_0] w-[1920px] box-sizing-border">
      <img className="absolute top-[-343px] right-[-203px] w-[709px] h-[799px]" />
      <div className="relative m-[0_94.1px_141.7px_56px] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        Home
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        About us
        </div>
        <div className="m-[27.3px_0_28px_0] flex flex-row justify-between w-[355.9px] h-[fit-content] box-sizing-border">
          <div className="rounded-[80px] bg-[#F5C572] relative flex p-[9.7px_0_11.3px_0.2px] w-[151px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
            Products
            </span>
          </div>
          <div className="m-[9.7px_0_11.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          Contact Us
          </div>
        </div>
      </div>
      <div className="relative m-[0_156.7px_19px_156.7px] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      High Pressure Pumps
      </div>
      <div className="relative m-[0_156px_196px_156px] inline-block self-start break-words font-['Montserrat'] font-medium text-[32px] tracking-[0.4px] text-[#FFFFFF]">
      Explore our range of water purification systems for industrial and residential purposes
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_145px_48px_156px] flex flex-row p-[62px_0_93px_107px] w-[1619px] box-sizing-border">
        <div className="bg-[url('assets/images/Regenerative3.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_141px_0_0] w-[365px] h-[295px]">
        </div>
        <div className="m-[42px_0_96px_0] flex flex-col items-end box-sizing-border">
          <div className="m-[0_0.3px_37px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          Regenerative
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FCFCFC] relative m-[0_145px_48px_156px] flex flex-row p-[51px_0_101px_107px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/ShallowWellJetPumpsMcjSeries11.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_141px_0_0] w-[365px] h-[298px]">
        </div>
        <div className="m-[52px_0_40px_0] flex flex-col items-center box-sizing-border">
          <div className="m-[0_0_37px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          Shallow well jet<br />
          pump MCJ
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_13.1px_0_0] flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_145px_48px_156px] flex flex-row p-[55px_0_97px_89px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/VerticalMultiStageCentrifugalPumpsLcrSeries61.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_159px_0_0] w-[365px] h-[298px]">
        </div>
        <div className="m-[28px_0_64px_0] flex flex-col box-sizing-border">
          <div className="m-[0_0_37px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          Vertical multistage centrifigal<br />
          pumps LCR series
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_62px_0_62px] flex self-start p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FCFCFC] relative m-[0_145px_48px_156px] flex flex-row p-[48px_0_103px_107px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/VerticalMultiStageCentrifugalPumpsMvrSeries11.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_141px_0_0] w-[365px] h-[299px]">
        </div>
        <div className="m-[64px_0_29px_0] flex flex-col box-sizing-border">
          <div className="m-[0_0_37px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          Vertical multistage centrifigal<br />
          pumps MVR series
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_62px_0_62px] flex self-start p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FCFCFC] relative m-[0_145px_48px_156px] flex flex-row p-[72px_0_80px_107px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/VerticalMultiStageOpenwellSubmersiblePumpsLcvSeries11.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_141px_0_0] w-[365px] h-[298px]">
        </div>
        <div className="m-[15px_0_70px_0] flex flex-col box-sizing-border">
          <div className="m-[0_0_44px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          Vertical multistage openwell<br />
          submersible pump LCV
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_62px_0_62px] flex self-start p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FCFCFC] relative m-[0_145px_150px_156px] flex flex-row p-[61px_0_91px_107px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/HorizontalMultistageCentrifugalPumpsMhSeries11.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_141px_0_0] w-[365px] h-[298px]">
        </div>
        <div className="m-[17px_0_26px_0] flex flex-col items-center box-sizing-border">
          <div className="m-[0_0_37px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          Horizontal multistage <br />
          centrifugal pumps <br />
          MH series
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_141.7px_0_0] flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[250px] bg-[#F5C572] relative m-[0_0_509px_44px] flex flex-row justify-between self-center p-[4px_10px_4px_0] w-[500px] box-sizing-border">
        <div className="m-[16px_18.5px_11px_0] inline-block w-[55px] break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#254A65]">
        1.
        </div>
        <div className="flex flex-row box-sizing-border">
          <div className="m-[13px_63.4px_14px_0] inline-block break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#254A65]">
          2.
          </div>
          <div className="rounded-[250px] bg-[#254A65] relative flex p-[10px_0_17px_11px] w-[164px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#FFFFFF]">
            3.
            </span>
          </div>
        </div>
      </div>
      <div className="relative flex p-[274px_84px_73.8px_84px] w-[1920px] box-sizing-border">
        <img className="rounded-tl-[500px] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]" />
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[137px] top-[190.9px] w-[632px] h-[395px]">
        </div>
        <div className="relative flex flex-col items-center w-[1591px] h-[fit-content] box-sizing-border">
          <div className="m-[0_0_20px_432px] flex flex-row justify-between w-[703px] box-sizing-border">
            <div className="rounded-[100px] bg-[#254A65] relative m-[3px_0_0_0] flex p-[17px_0_19px_4.3px] w-[226px] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Explore
              </span>
            </div>
            <div className="rounded-[100px] bg-[#254A65] relative m-[0_0_3px_0] flex p-[20px_19.8px_16px_22px] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Get In touch
              </span>
            </div>
          </div>
          <div className="m-[0_0_29.7px_545.6px] flex flex-row justify-between w-[726.6px] box-sizing-border">
            <div className="m-[0_18px_0.3px_0] inline-block w-[117px] break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
            Home
            </div>
            <div className="flex flex-row box-sizing-border">
              <div className="m-[8px_26.6px_0_0] flex w-[45px] h-[40px] box-sizing-border">
                <img className="rounded-[2px] w-[31.9px] h-[28.3px]" />
              </div>
              <div className="m-[0_0_0.3px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
              +91 9030027002
              </div>
            </div>
          </div>
          <div className="m-[0_49px_23.1px_0] flex flex-row justify-between w-[1542px] box-sizing-border">
            <div className="relative m-[114.9px_33px_0_0] inline-block w-[417px] break-words font-['Source_Serif_Pro','Roboto_Condensed'] font-bold text-[56px] tracking-[0.4px] text-[#000000]">
            A1 Splash Aqua
            </div>
            <div className="m-[0_0_12.9px_0] flex flex-row box-sizing-border">
              <div className="m-[0_124.1px_0_0] flex flex-col box-sizing-border">
                <div className="m-[0_0_30px_0] inline-block self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                About Us
                </div>
                <div className="m-[0_0_30px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Products &amp; Services
                </div>
                <span className="self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Contact Us
                </span>
              </div>
              <div className="m-[20px_26.3px_34.7px_0] flex flex-col items-center w-[33.8px] h-[fit-content] box-sizing-border">
                <div className="m-[0_5.1px_60px_4.3px] flex w-[45px] h-[40px] box-sizing-border">
                  <img className="w-[24.4px] h-[30px]" />
                </div>
                <div className="flex w-[45px] h-[40px] box-sizing-border">
                  <img className="rounded-[2px] w-[33.8px] h-[23.3px]" />
                </div>
              </div>
              <div className="m-[3px_0_31px_0] flex flex-col items-center box-sizing-border">
                <div className="m-[0_13px_26px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Lakshmipuram 4 th lane Guntur - 522007
                </div>
                <span className="break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                mannepavan@gmail.com
                </span>
              </div>
            </div>
          </div>
          <img className="self-end w-[94px] h-[89.1px]" />
        </div>
      </div>
    </div>
  )
}