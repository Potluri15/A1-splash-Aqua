export default function ProductList8() {
  return (
    <div className="bg-[#254A65] flex flex-col p-[0_0_9.1px_0] w-[1920px] box-sizing-border">
      <img className="absolute top-[-122px] right-[-128px] w-[650px] h-[579px]" />
      <div className="relative m-[0_94.1px_134.7px_56px] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        Home
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        About us
        </div>
        <div className="m-[27.3px_0_28px_0] flex flex-row justify-between w-[355.9px] h-[fit-content] box-sizing-border">
          <div className="rounded-[80px] bg-[#F5C572] relative flex p-[9.7px_0_11.3px_0.2px] w-[151px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
            Products
            </span>
          </div>
          <div className="m-[9.7px_0_11.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          Contact Us
          </div>
        </div>
      </div>
      <div className="relative m-[0_159.2px_18px_159.2px] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Multiport Valves
      </div>
      <div className="relative m-[0_159px_304px_159px] inline-block self-start break-words font-['Montserrat'] font-medium text-[32px] tracking-[0.4px] text-[#FFFFFF]">
      Explore our range of water purification systems for industrial and residential purposes
      </div>
      <div className="relative m-[0_45px_81px_0] inline-block self-center break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      AUTOMATIC
      </div>
      <div className="relative m-[0_149px_48px_48px] flex flex-row w-[fit-content] box-sizing-border">
        <div className="bg-[url('assets/images/NbAmpv2.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[20px_104px_430px_0] w-[0px] h-[0px]">
        </div>
        <div className="rounded-[80px] bg-[#FFFFFF] relative flex flex-row p-[105px_0_107px_106px] w-[1619px] box-sizing-border">
          <div className="rounded-[30px] bg-[url('assets/images/NbAmpv2.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_154px_0_0] w-[375px] h-[238px]">
          </div>
          <div className="m-[48px_0_30px_0] flex flex-col items-end box-sizing-border">
            <div className="m-[0_0.8px_40px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
            25NB-AMPV
            </div>
            <div className="rounded-[250px] bg-[#F5C572] relative flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
              <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
              Learn more
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_155px_48px_146px] flex flex-row p-[109px_0_143.2px_112px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/NbTopSdeMountAutomatic1.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_154px_0_0] w-[375px] h-[197.8px]">
        </div>
        <div className="m-[29px_0_7.8px_0] flex flex-col box-sizing-border">
          <div className="m-[0_0_41px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          40NB top-side mount
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_42px_0_42px] flex self-start p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_153px_48px_148px] flex flex-row p-[102px_0_95px_110px] w-[1619px] box-sizing-border">
        <div className="rounded-[30px] bg-[url('assets/images/NbSideMountAutomatic1.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_154px_55.2px_0] w-[375px] h-[197.8px]">
        </div>
        <div className="m-[93px_0_0_0] flex flex-col items-center box-sizing-border">
          <div className="m-[0_0_40px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
          65NB side mount
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_61.5px_0_0] flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="relative m-[0_151px_48px_150px] flex w-[1619px] box-sizing-border">
        <div className="rounded-[80px] bg-[#FFFFFF] relative flex flex-row p-[132px_0_120.2px_108px] w-[1619px] box-sizing-border">
          <div className="rounded-[30px] bg-[url('assets/images/IsoloBasicAutomaticValve2.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_154px_0_0] w-[375px] h-[197.8px]">
          </div>
          <div className="m-[29px_0_7.8px_0] flex flex-col items-end box-sizing-border">
            <div className="m-[0_24.8px_41px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
            I-solo basic 
            </div>
            <div className="rounded-[250px] bg-[#F5C572] relative flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
              <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
              Learn more
              </span>
            </div>
          </div>
        </div>
        <div className="bg-[url('assets/images/IsoloBasicAutomaticValve2.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[45px] top-[220px] w-[0px] h-[0px]">
        </div>
      </div>
      <div className="relative m-[0_149px_48px_152px] flex w-[1619px] box-sizing-border">
        <div className="rounded-[80px] bg-[#FFFFFF] relative flex flex-row p-[108px_0_144px_106px] w-[1619px] box-sizing-border">
          <div className="rounded-[30px] bg-[url('assets/images/WirefreeAmpv2.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_154px_0.2px_0] w-[375px] h-[197.8px]">
          </div>
          <div className="m-[30px_0_0_0] flex flex-col items-center box-sizing-border">
            <div className="m-[0_0_48px_0] inline-block break-words font-['Montserrat'] font-bold text-[40px] tracking-[0.4px] text-[#000000]">
            Wirefree-AMPV
            </div>
            <div className="rounded-[250px] bg-[#F5C572] relative m-[0_24.5px_0_0] flex p-[27px_0_26px_0] w-[222px] box-sizing-border">
              <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
              Learn more
              </span>
            </div>
          </div>
        </div>
        <div className="bg-[url('assets/images/WirefreeAmpv2.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[63px] top-[186px] w-[0px] h-[0px]">
        </div>
      </div>
      <div className="rounded-[80px] bg-[#FFFFFF] relative m-[0_150px_947px_151px] flex flex-row p-[100px_0_101px_114px] w-[1619px] box-sizing-border">
        <div className="bg-[url('assets/images/Image1108.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_137px_0_0] w-[426px] h-[249px]">
        </div>
        <div className="m-[52px_0_53px_0] flex flex-col box-sizing-border">
          <div className="m-[0_0_34px_0] inline-block break-words font-['Montserrat'] font-bold text-[32px] tracking-[0.4px] text-[#000000]">
          MPV-FTM40FF
          </div>
          <div className="rounded-[250px] bg-[#F5C572] relative m-[0_1px_0_1px] flex self-start p-[27px_0_26px_0] w-[222px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
            Learn more
            </span>
          </div>
        </div>
      </div>
      <div className="relative flex p-[274px_84px_73.8px_84px] w-[1920px] box-sizing-border">
        <img className="rounded-tl-[500px] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]" />
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[137px] top-[190.9px] w-[632px] h-[395px]">
        </div>
        <div className="relative flex flex-col items-center w-[1591px] h-[fit-content] box-sizing-border">
          <div className="m-[0_0_20px_432px] flex flex-row justify-between w-[703px] box-sizing-border">
            <div className="rounded-[100px] bg-[#254A65] relative m-[3px_0_0_0] flex p-[17px_0_19px_4.3px] w-[226px] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Explore
              </span>
            </div>
            <div className="rounded-[100px] bg-[#254A65] relative m-[0_0_3px_0] flex p-[20px_19.8px_16px_22px] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Get In touch
              </span>
            </div>
          </div>
          <div className="m-[0_0_29.7px_545.6px] flex flex-row justify-between w-[726.6px] box-sizing-border">
            <div className="m-[0_18px_0.3px_0] inline-block w-[117px] break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
            Home
            </div>
            <div className="flex flex-row box-sizing-border">
              <div className="m-[8px_26.6px_0_0] flex w-[45px] h-[40px] box-sizing-border">
                <img className="rounded-[2px] w-[31.9px] h-[28.3px]" />
              </div>
              <div className="m-[0_0_0.3px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
              +91 9030027002
              </div>
            </div>
          </div>
          <div className="m-[0_49px_23.1px_0] flex flex-row justify-between w-[1542px] box-sizing-border">
            <div className="relative m-[114.9px_33px_0_0] inline-block w-[417px] break-words font-['Source_Serif_Pro','Roboto_Condensed'] font-bold text-[56px] tracking-[0.4px] text-[#000000]">
            A1 Splash Aqua
            </div>
            <div className="m-[0_0_12.9px_0] flex flex-row box-sizing-border">
              <div className="m-[0_124.1px_0_0] flex flex-col box-sizing-border">
                <div className="m-[0_0_30px_0] inline-block self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                About Us
                </div>
                <div className="m-[0_0_30px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Products &amp; Services
                </div>
                <span className="self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Contact Us
                </span>
              </div>
              <div className="m-[20px_26.3px_34.7px_0] flex flex-col items-center w-[33.8px] h-[fit-content] box-sizing-border">
                <div className="m-[0_5.1px_60px_4.3px] flex w-[45px] h-[40px] box-sizing-border">
                  <img className="w-[24.4px] h-[30px]" />
                </div>
                <div className="flex w-[45px] h-[40px] box-sizing-border">
                  <img className="rounded-[2px] w-[33.8px] h-[23.3px]" />
                </div>
              </div>
              <div className="m-[3px_0_31px_0] flex flex-col items-center box-sizing-border">
                <div className="m-[0_13px_26px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Lakshmipuram 4 th lane Guntur - 522007
                </div>
                <span className="break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                mannepavan@gmail.com
                </span>
              </div>
            </div>
          </div>
          <img className="self-end w-[94px] h-[89.1px]" />
        </div>
      </div>
    </div>
  )
}