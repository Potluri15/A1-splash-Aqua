export default function Property1Variant4() {
  return (
    <div className="flex flex-row justify-between w-[1807.3px] box-sizing-border">
      <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
      </div>
      <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
      Home
      </div>
      <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
      About us
      </div>
      <div className="m-[28px_0px_27.3px_0] flex flex-row justify-between w-[345.2px] h-[fit-content] box-sizing-border">
        <div className="m-[9px_12px_12px_0] inline-block w-[105.2px] break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Products
        </div>
        <div className="rounded-[80px] bg-[#F5C572] relative flex p-[9px_16.1px_12px_16.3px] box-sizing-border">
          <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          Contact Us
          </span>
        </div>
      </div>
    </div>
  )
}