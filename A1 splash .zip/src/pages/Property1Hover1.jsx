export default function Property1Hover1() {
  return (
    <div className="p-[0_0_47px_0] box-sizing-border">
      <span className="relative break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#000000]">
      label
      </span>
      <div className="rounded-[5px] border-[1px_solid_#222222] bg-[#FFFFFF] absolute left-[0px] right-[0px] bottom-[0px] p-[9px_14px_9px_14px] box-sizing-border">
        <span className="break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#D2D2D2]">
        label
        </span>
      </div>
    </div>
  )
}