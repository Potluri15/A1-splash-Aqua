export default function ContactUs() {
  return (
    <div className="bg-[#254A65] flex flex-col items-center p-[0_0_0.1px_0] w-[1920px] box-sizing-border">
      <img className="absolute top-[-161px] right-[-23.2px] w-[569.2px] h-[502.6px]" />
      <div className="relative m-[0_78px_259.7px_56px] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        Home
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        About us
        </div>
        <div className="m-[28px_0_27.3px_0] flex flex-row justify-between w-[345.2px] h-[fit-content] box-sizing-border">
          <div className="m-[9px_12px_12px_0] inline-block w-[105.2px] break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          Products
          </div>
          <div className="rounded-[80px] bg-[#F5C572] relative flex p-[9px_16.1px_12px_16.3px] box-sizing-border">
            <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
            Contact Us
            </span>
          </div>
        </div>
      </div>
      <div className="relative m-[0_114px_33px_114px] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Contact Us
      </div>
      <div className="relative m-[0_124px_334px_124px] inline-block self-start break-words font-['Montserrat'] font-medium text-[32px] tracking-[0.4px] text-[#FFFFFF]">
      Get in touch with us to explore our water purifying solutions
      </div>
      <div className="relative m-[0_113px_184px_113px] flex flex-row self-end w-[fit-content] box-sizing-border">
        <div className="m-[77px_40px_36px_0] flex flex-col items-center w-[100px] h-[fit-content] box-sizing-border">
          <div className="bg-[url('assets/images/Email.png')] bg-[50%_50%] bg-contain bg-no-repeat m-[0_0_223px_0] w-[100px] h-[100px]">
          </div>
          <div className="bg-[url('assets/images/Phone.png')] bg-[50%_50%] bg-contain bg-no-repeat m-[0_0_223px_0] w-[100px] h-[100px]">
          </div>
          <div className="bg-[url('assets/images/Location.png')] bg-[50%_50%] bg-contain bg-no-repeat w-[100px] h-[100px]">
          </div>
        </div>
        <div className="relative m-[0_229.2px_0_0] flex p-[0_0_0_0px] box-sizing-border">
          <div className="relative flex flex-col box-sizing-border">
            <div className="m-[0_4.6px_2px_4.6px] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
            Email
            </div>
            <div className="m-[0_0_8px_0.2px] inline-block break-words font-['Montserrat'] font-normal text-[32px] tracking-[0.4px] text-[#FFFFFF]">
            Send us and email today
            </div>
            <div className="m-[0_0_145px_0] inline-block self-start break-words font-['Montserrat'] font-normal text-[32px] tracking-[0.4px] text-[#FFFFFF]">
            xyjklm@aaa.com
            </div>
            <div className="m-[0_0.5px_48px_0.5px] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
            Phone
            </div>
            <div className="m-[0_0.3px_179px_0.3px] inline-block self-start break-words font-['Montserrat'] font-normal text-[32px] tracking-[0.4px] text-[#FFFFFF]">
            +91 9505066886
            </div>
            <span className="m-[0_0.4px_0_0.4px] self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
            Office
            </span>
            <span className="m-[0_1.9px_0_0] break-words font-['Montserrat'] font-normal text-[32px] tracking-[0.4px] text-[#FFFFFF]">
            Lakshmipuram 4 th lane Guntur - 522007
            </span>
          </div>
          <span className="absolute left-[0px] bottom-[400px] break-words font-['Montserrat'] font-normal text-[32px] tracking-[0.4px] text-[#FFFFFF]">
          Call us for assistance
          </span>
        </div>
        <div className="bg-[url('assets/images/CoolKidsAloneTime1.png')] bg-[50%_50%] bg-cover bg-no-repeat m-[67px_0_36px_0] w-[800px] h-[756px]">
        </div>
      </div>
      <div className="relative m-[0_0_13px_1px] inline-block break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Get In Touch
      </div>
      <div className="relative m-[0_0_77.3px_0] inline-block text-center break-words font-['Montserrat'] font-normal text-[32px] tracking-[0.4px] text-[#FFFFFF]">
      Have a question or need assistance? Contact us today, We’ll get back to you
      </div>
      <div className="relative m-[0_0_112px_0] flex flex-col items-center w-[1100px] box-sizing-border">
        <div className="m-[0_0_84.3px_0] flex flex-row justify-between w-[1100px] box-sizing-border">
          <div className="relative m-[0_0_19px_0] p-[0_0_46.7px_0] w-[443px] box-sizing-border">
            <span className="relative break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#FFFFFF]">
            First Name
            </span>
            <div className="rounded-[5px] border-[1px_solid_#E2E1E5] bg-[#FFFFFF] absolute left-[50%] bottom-[0px] translate-x-[-50%] p-[9px_14px_9px_14px] w-[443px] box-sizing-border">
              <span className="break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#D2D2D2]">
               First Name
              </span>
            </div>
          </div>
          <div className="relative m-[19px_0_0_0] p-[0_0_46.7px_0] w-[443px] box-sizing-border">
            <span className="relative break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#FFFFFF]">
            Last Name
            </span>
            <div className="rounded-[5px] border-[1px_solid_#E2E1E5] bg-[#FFFFFF] absolute left-[50%] bottom-[0px] translate-x-[-50%] p-[9px_14px_9px_14px] w-[443px] box-sizing-border">
              <span className="break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#D2D2D2]">
              Last Name
              </span>
            </div>
          </div>
        </div>
        <div className="flex flex-row justify-between w-[1100px] box-sizing-border">
          <div className="relative m-[1px_0_0_0] p-[0_0_46.7px_0] w-[443px] box-sizing-border">
            <span className="relative break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#FFFFFF]">
            Email
            </span>
            <div className="rounded-[5px] border-[1px_solid_#E2E1E5] bg-[#FFFFFF] absolute left-[50%] bottom-[0px] translate-x-[-50%] p-[9px_14px_9px_14px] w-[443px] box-sizing-border">
              <span className="break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#D2D2D2]">
              Email
              </span>
            </div>
          </div>
          <div className="relative m-[0_0_1px_0] p-[0_0_46.7px_0] w-[443px] box-sizing-border">
            <span className="relative break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#FFFFFF]">
            Phone Number
            </span>
            <div className="rounded-[5px] border-[1px_solid_#E2E1E5] bg-[#FFFFFF] absolute left-[50%] bottom-[0px] translate-x-[-50%] p-[9px_14px_9px_14px] w-[443px] box-sizing-border">
              <span className="break-words font-['Inter'] font-normal text-[14px] leading-[2] text-[#D2D2D2]">
              Phone Number
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="rounded-[250px] bg-[#FFFFFF] relative m-[0_1px_201px_0] flex p-[26px_0_28px_0] w-[221px] box-sizing-border">
        <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#254A65]">
        Enquire
        </span>
      </div>
      <div className="relative m-[0_0_7px_1px] inline-block break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Location
      </div>
      <div className="relative m-[0_0_40px_0] inline-block break-words font-['Montserrat'] font-medium text-[32px] tracking-[0.4px] text-[#FFFFFF]">
      Find our office and service area near you.
      </div>
      <div className="bg-[url('assets/images/Screenshot20240903At10021Pm1.png')] bg-[50%_50%] bg-cover bg-no-repeat relative m-[0_0_34.3px_0] w-[1000px] h-[523.7px]">
      </div>
      <div className="relative m-[0_0_34px_0] inline-block break-words font-['Montserrat'] font-medium text-[30px] tracking-[0.4px] text-[#FFFFFF]">
      Lakshmipuram 4 th lane Guntur - 522007
      </div>
      <div className="relative m-[0_0_215px_1px] inline-block break-words font-['Montserrat'] font-normal text-[36px] tracking-[0.4px] text-[#FFFFFF]">
      Get Directions &gt;
      </div>
      <div className="relative flex p-[274px_84px_73.8px_84px] w-[1920px] box-sizing-border">
        <img className="rounded-tl-[500px] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]" />
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[137px] top-[190.9px] w-[632px] h-[395px]">
        </div>
        <div className="relative flex flex-col items-center w-[1591px] h-[fit-content] box-sizing-border">
          <div className="m-[0_0_20px_432px] flex flex-row justify-between w-[703px] box-sizing-border">
            <div className="rounded-[100px] bg-[#254A65] relative m-[3px_0_0_0] flex p-[17px_0_19px_4.3px] w-[226px] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Explore
              </span>
            </div>
            <div className="rounded-[100px] bg-[#254A65] relative m-[0_0_3px_0] flex p-[20px_19.8px_16px_22px] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Get In touch
              </span>
            </div>
          </div>
          <div className="m-[0_0_29.7px_545.6px] flex flex-row justify-between w-[726.6px] box-sizing-border">
            <div className="m-[0_18px_0.3px_0] inline-block w-[117px] break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
            Home
            </div>
            <div className="flex flex-row box-sizing-border">
              <div className="m-[8px_26.6px_0_0] flex w-[45px] h-[40px] box-sizing-border">
                <img className="rounded-[2px] w-[31.9px] h-[28.3px]" />
              </div>
              <div className="m-[0_0_0.3px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
              +91 9030027002
              </div>
            </div>
          </div>
          <div className="m-[0_49px_23.1px_0] flex flex-row justify-between w-[1542px] box-sizing-border">
            <div className="relative m-[114.9px_33px_0_0] inline-block w-[417px] break-words font-['Source_Serif_Pro','Roboto_Condensed'] font-bold text-[56px] tracking-[0.4px] text-[#000000]">
            A1 Splash Aqua
            </div>
            <div className="m-[0_0_12.9px_0] flex flex-row box-sizing-border">
              <div className="m-[0_124.1px_0_0] flex flex-col box-sizing-border">
                <div className="m-[0_0_30px_0] inline-block self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                About Us
                </div>
                <div className="m-[0_0_30px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Products &amp; Services
                </div>
                <span className="self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Contact Us
                </span>
              </div>
              <div className="m-[20px_26.3px_34.7px_0] flex flex-col items-center w-[33.8px] h-[fit-content] box-sizing-border">
                <div className="m-[0_5.1px_60px_4.3px] flex w-[45px] h-[40px] box-sizing-border">
                  <img className="w-[24.4px] h-[30px]" />
                </div>
                <div className="flex w-[45px] h-[40px] box-sizing-border">
                  <img className="rounded-[2px] w-[33.8px] h-[23.3px]" />
                </div>
              </div>
              <div className="m-[3px_0_31px_0] flex flex-col items-center box-sizing-border">
                <div className="m-[0_13px_26px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Lakshmipuram 4 th lane Guntur - 522007
                </div>
                <span className="break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                mannepavan@gmail.com
                </span>
              </div>
            </div>
          </div>
          <img className="self-end w-[94px] h-[89.1px]" />
        </div>
      </div>
    </div>
  )
}