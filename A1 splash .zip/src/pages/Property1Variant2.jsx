export default function Property1Variant2() {
  return (
    <div className="rounded-[250px] bg-[#F5C572] flex flex-row justify-between p-[4px_0_4px_0] box-sizing-border">
      <div className="m-[16px_18.5px_11px_0] inline-block w-[55px] break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#282F55]">
      1.
      </div>
      <div className="rounded-[250px] bg-[#282F55] relative flex p-[13px_1px_14px_0] w-[164px] h-[fit-content] box-sizing-border">
        <span className="break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#FFFFFF]">
        2.
        </span>
      </div>
      <div className="m-[10px_0_17px_0] inline-block break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#284D55]">
      3.
      </div>
    </div>
  )
}