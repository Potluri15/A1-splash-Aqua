export default function ThankYouPage() {
  return (
    <div className="bg-[#254A65] flex flex-col items-center p-[0_94.1px_379.5px_56px] w-[1920px] box-sizing-border">
      <img className="absolute top-[-183px] right-[-166px] w-[656px] h-[602px]" />
      <div className="relative m-[0_0_228.7px_0] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="rounded-[80px] bg-[#FFFFFF] relative m-[28px_0_27.3px_0] flex p-[9px_0_12px_2.2px] w-[151px] h-[fit-content] box-sizing-border">
          <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#282F55]">
          Home
          </span>
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        About us
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Products
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Contact Us
        </div>
      </div>
      <div className="shadow-[0px_0px_5.8px_0.8px_rgba(0,0,0,0.25)] rounded-[677.6px] border-[7.8px_solid_var(--stroke,#F7F7F8)] bg-[var(--bg-background-image,linear-gradient(0deg,#B2B2B2_10.3%,#FFFFFF_95%))] bg-[var(--bg-background-position-x,)_var(--bg-background-position-y,)] bg-[length:var(--bg-background-size,)] bg-var(--bg-background-repeat, ) bg-var( bg-var( relative m-[0_0_71px_38.1px] w-[180px] h-[180px]">
        <img className="absolute left-[-3925px] top-[20.9px] w-[4485.4px] h-[401.4px]" />
        <img className="absolute left-[-3549.7px] top-[20.9px] w-[4485.4px] h-[401.4px]" />
        <img className="absolute top-[20.9px] right-[-4162px] w-[4485.4px] h-[401.4px]" />
        <img className="absolute top-[20.9px] right-[-4049.9px] w-[4485.4px] h-[401.4px]" />
      </div>
      <div className="relative m-[0_0_0_39.1px] flex flex-col items-end w-[fit-content] box-sizing-border">
        <div className="m-[0_53.7px_9.5px_53.7px] inline-block break-words font-['IM_FELL_French_Canon'] font-normal text-[35px] tracking-[0.4px] text-[#FFFFFF]">
        Thank you for contacting us
        </div>
        <span className="break-words font-['IM_FELL_French_Canon'] font-normal text-[60px] tracking-[0.4px] text-[#FFFFFF]">
        We’ll get back to you
        </span>
      </div>
    </div>
  )
}