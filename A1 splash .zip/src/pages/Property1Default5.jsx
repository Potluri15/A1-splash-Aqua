export default function Property1Default5() {
  return (
    <div className="rounded-[250px] bg-[#F5C572] flex p-[26px_0_28px_0] box-sizing-border">
      <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
      Enquire
      </span>
    </div>
  )
}