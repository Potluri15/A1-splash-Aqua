export default function Property1Default4() {
  return (
    <div className="rounded-[250px] bg-[#F5C572] flex p-[27px_0_26px_0] box-sizing-border">
      <span className="break-words font-['Montserrat'] font-bold text-[15px] tracking-[0.4px] text-[#000000]">
      Learn more
      </span>
    </div>
  )
}