export default function Property1Variant31() {
  return (
    <div className="flex flex-row justify-between w-[1807.3px] box-sizing-border">
      <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
      </div>
      <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
      Home
      </div>
      <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
      About us
      </div>
      <div className="m-[27.3px_0px_28px_0] flex flex-row justify-between w-[355.9px] h-[fit-content] box-sizing-border">
        <div className="rounded-[80px] bg-[#F5C572] relative flex p-[9.7px_0_11.3px_0.2px] w-[151px] box-sizing-border">
          <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
          Products
          </span>
        </div>
        <div className="m-[9.7px_0_11.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Contact Us
        </div>
      </div>
    </div>
  )
}