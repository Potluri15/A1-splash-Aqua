export default function AboutUs() {
  return (
    <div className="bg-[#254A65] flex flex-col p-[0_7px_0.1px_0] w-[1920px] box-sizing-border">
      <img className="absolute top-[-228px] right-[-152px] w-[738px] h-[783px]" />
      <div className="relative m-[0_87.1px_247.7px_56px] flex flex-row justify-between w-[1807.3px] box-sizing-border">
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat w-[179.4px] h-[100.3px]">
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#FFFFFF]">
        Home
        </div>
        <div className="rounded-[80px] bg-[#FFFFFF] relative m-[27.7px_0_27.7px_0] flex p-[9.3px_1.8px_11.7px_0] w-[151px] h-[fit-content] box-sizing-border">
          <span className="break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#254A65]">
          About us
          </span>
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Products
        </div>
        <div className="m-[37px_0_39.3px_0] inline-block break-words font-['Montserrat'] font-bold text-[20px] tracking-[0.4px] text-[#000000]">
        Contact Us
        </div>
      </div>
      <div className="relative m-[0_50px_137px_80px] flex flex-row w-[fit-content] box-sizing-border">
        <div className="m-[43px_95.9px_0_0] flex flex-col box-sizing-border">
          <div className="m-[0_0_135px_0] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
          About Us
          </div>
          <span className="break-words font-['Montserrat'] font-medium text-[32px] tracking-[0.4px] text-[#FFFFFF]">
          We would like to introduce our company AQUAMAX Group that has been in &#34;Total Water Management Solutions&#34; under one roof for both domestic and industrial applications&#39; for the past 25 years. We have been an established and popular company with an excellent track record for the best customer satisfaction. We have never compromised on the quality and the services provided to the customer. We believe in keeping the customers happy and providing them with products at a very competent price. We have an excellent technical staff, who will guide you with their best ideas by keeping in constant touch with your company, Please feel free to keep in touch with us about any of your business related requirements/queries.&#34;
          </span>
        </div>
        <div className="rounded-[30px] bg-[url('assets/images/WhatsAppImage20240727At124928E854C45C3.jpeg')] bg-[50%_50%] bg-cover bg-no-repeat m-[0_0_55px_0] w-[616px] h-[685px]">
        </div>
      </div>
      <div className="relative m-[0_80px_18px_80px] inline-block self-start break-words font-['IM_FELL_French_Canon'] font-normal text-[80px] tracking-[0.4px] text-[#FFFFFF]">
      Meet Our Team
      </div>
      <div className="relative m-[0_80px_192px_80px] inline-block self-start break-words font-['Montserrat'] font-medium text-[32px] tracking-[0.4px] text-[#FFFFFF]">
      Get to know the key members of our team
      </div>
      <div className="relative m-[0_80px_17px_80px] flex flex-row justify-between self-start w-[1268px] box-sizing-border">
        <img className="w-[83px] h-[80px]" />
        <img className="w-[83px] h-[80px]" />
        <img className="w-[83px] h-[80px]" />
        <img className="w-[83px] h-[80px]" />
      </div>
      <div className="relative m-[0_93px_4px_93px] flex flex-row justify-between self-start w-[1259.7px] box-sizing-border">
        <div className="m-[1px_18.5px_0_0] inline-block w-[83px] break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#FFFFFF]">
        ABC
        </div>
        <div className="m-[1px_0_0_0] inline-block break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#FFFFFF]">
        ABC
        </div>
        <div className="m-[1px_0_0_0] inline-block break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#FFFFFF]">
        ABC
        </div>
        <div className="m-[0_0_1px_0] inline-block break-words font-['Montserrat'] font-bold text-[30px] tracking-[0.4px] text-[#FFFFFF]">
        ABC
        </div>
      </div>
      <div className="relative m-[0_93px_10px_93px] flex flex-row justify-between self-start w-[1247.6px] box-sizing-border">
        <span className="m-[0_15px_0_0] w-[57px] break-words font-['Montserrat'] font-medium text-[25px] tracking-[0.4px] text-[#FFFFFF]">
        CEO
        </span>
        <span className="break-words font-['Montserrat'] font-medium text-[25px] tracking-[0.4px] text-[#FFFFFF]">
        CEO
        </span>
        <span className="break-words font-['Montserrat'] font-medium text-[25px] tracking-[0.4px] text-[#FFFFFF]">
        CEO
        </span>
        <span className="break-words font-['Montserrat'] font-medium text-[25px] tracking-[0.4px] text-[#FFFFFF]">
        CEO
        </span>
      </div>
      <div className="relative m-[0_93px_573px_93px] flex flex-row self-start w-[fit-content] box-sizing-border">
        <div className="m-[6px_47.5px_0_0] inline-block break-words font-['Montserrat'] font-medium text-[24px] tracking-[0.4px] text-[#FFFFFF]">
        A visionary leader<br />
        with extensive experience <br />
        in the company.
        </div>
        <div className="m-[0_47.5px_6px_0] inline-block break-words font-['Montserrat'] font-medium text-[24px] tracking-[0.4px] text-[#FFFFFF]">
        A visionary leader<br />
        with extensive experience <br />
        in the company.
        </div>
        <div className="m-[6px_53.5px_0_0] inline-block break-words font-['Montserrat'] font-medium text-[24px] tracking-[0.4px] text-[#FFFFFF]">
        A visionary leader<br />
        with extensive experience <br />
        in the company.
        </div>
        <div className="m-[0_0_6px_0] inline-block break-words font-['Montserrat'] font-medium text-[24px] tracking-[0.4px] text-[#FFFFFF]">
        A visionary leader<br />
        with extensive experience <br />
        in the company.
        </div>
      </div>
      <div className="relative flex p-[274px_84px_73.8px_84px] w-[1920px] box-sizing-border">
        <img className="rounded-tl-[500px] absolute left-[0px] top-[0px] right-[0px] bottom-[0px] h-[100%]" />
        <div className="bg-[url('assets/images/LogoFinalRemovebgPreview1.png')] bg-[50%_50%] bg-cover bg-no-repeat absolute left-[137px] top-[190.9px] w-[632px] h-[395px]">
        </div>
        <div className="relative flex flex-col items-center w-[1591px] h-[fit-content] box-sizing-border">
          <div className="m-[0_0_20px_432px] flex flex-row justify-between w-[703px] box-sizing-border">
            <div className="rounded-[100px] bg-[#254A65] relative m-[3px_0_0_0] flex p-[17px_0_19px_4.3px] w-[226px] h-[fit-content] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Explore
              </span>
            </div>
            <div className="rounded-[100px] bg-[#254A65] relative m-[0_0_3px_0] flex p-[20px_19.8px_16px_22px] box-sizing-border">
              <span className="break-words font-['Inter'] font-semibold text-[38px] tracking-[0.4px] text-[#FFFFFF]">
              Get In touch
              </span>
            </div>
          </div>
          <div className="m-[0_0_29.7px_545.6px] flex flex-row justify-between w-[726.6px] box-sizing-border">
            <div className="m-[0_18px_0.3px_0] inline-block w-[117px] break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
            Home
            </div>
            <div className="flex flex-row box-sizing-border">
              <div className="m-[8px_26.6px_0_0] flex w-[45px] h-[40px] box-sizing-border">
                <img className="rounded-[2px] w-[31.9px] h-[28.3px]" />
              </div>
              <div className="m-[0_0_0.3px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
              +91 9030027002
              </div>
            </div>
          </div>
          <div className="m-[0_49px_23.1px_0] flex flex-row justify-between w-[1542px] box-sizing-border">
            <div className="relative m-[114.9px_33px_0_0] inline-block w-[417px] break-words font-['Source_Serif_Pro','Roboto_Condensed'] font-bold text-[56px] tracking-[0.4px] text-[#000000]">
            A1 Splash Aqua
            </div>
            <div className="m-[0_0_12.9px_0] flex flex-row box-sizing-border">
              <div className="m-[0_124.1px_0_0] flex flex-col box-sizing-border">
                <div className="m-[0_0_30px_0] inline-block self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                About Us
                </div>
                <div className="m-[0_0_30px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Products &amp; Services
                </div>
                <span className="self-start break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Contact Us
                </span>
              </div>
              <div className="m-[20px_26.3px_34.7px_0] flex flex-col items-center w-[33.8px] h-[fit-content] box-sizing-border">
                <div className="m-[0_5.1px_60px_4.3px] flex w-[45px] h-[40px] box-sizing-border">
                  <img className="w-[24.4px] h-[30px]" />
                </div>
                <div className="flex w-[45px] h-[40px] box-sizing-border">
                  <img className="rounded-[2px] w-[33.8px] h-[23.3px]" />
                </div>
              </div>
              <div className="m-[3px_0_31px_0] flex flex-col items-center box-sizing-border">
                <div className="m-[0_13px_26px_0] inline-block break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                Lakshmipuram 4 th lane Guntur - 522007
                </div>
                <span className="break-words font-['Inter'] font-normal text-[30px] tracking-[0.4px] text-[#000000]">
                mannepavan@gmail.com
                </span>
              </div>
            </div>
          </div>
          <img className="self-end w-[94px] h-[89.1px]" />
        </div>
      </div>
    </div>
  )
}