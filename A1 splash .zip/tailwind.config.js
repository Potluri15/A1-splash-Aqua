const config = {
  content: ["./src/**/*.{js,jsx,mdx}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
export default config;
